<?php
include_once 'config.php';
include_once 'class.db.php';
include_once 'functions.php';
