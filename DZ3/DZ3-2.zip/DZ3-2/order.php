<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

include_once 'config.php';

function connect()
{
    global $pdo;
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=db;port=3306', DB_USER, DB_PASSWORD);
    return $pdo;
}


function valider($link, $email)
{
    $query = "SELECT * FROM `users` WHERE `email` = 'example@mail.local'";
    $result = mysqli_query($link, $query);
    if(!$result) die($link>error);
    var_dump($result);
}
$pdo = connect();
var_dump($pdo);
valider($pdo,'');

//
//function getUser($data ['email']);
//{
//global $pdo;
//$sql = "SELECT * FROM `db`.`users` WHERE email = :email";
//return $pdo->fetchOne($query,['email' =>$email]);
//{
//
//
//function addUser($data)
//{global $pdo;
//    $sql = "INSERT INTO `db`.`users` (`email`, `name`) VALUES (:email, :name )";
//    $stmt= $pdo->prepare($sql);
//    $stmt->execute($data);
//}
//function update ($data)
//{global $pdo;
//$sql = "UPDATE users SET name=:name, email=:email, orders=:orders, 'name'=:name WHERE id=:id";
//    $stmt = $pdo->prepare($sql);
//    $stmt->execute($data);
//}
//function select ($data)
//{
//    global $pdo;
//    $stmt = $pdo->query("SELECT * FROM users");
//}
//
//function addOrder($data['email']);
//{
//    global $pdo;
//    $sql = "INSERT INTO `db`.`users` (user_Id, address, create) VALUES (:user_Id, :address, :create)";
//    $result = $db->exec($sql
//        [
//            'user_Id' => $user_Id,
//            'address' => 'create',
//            $data['address'] => date('Y-m-d H:i:s'),
//        ]
//
//}
//
//
//
//function main()
//{
//    global $pdo;
//    connect();
//    var_dump($pdo);
//    exit();
//    $burger = new Burger();
//    $email = $_POST['email'];
//    $name = $_POST['name'];
//    $addressFields = ['phone', 'street', 'home', 'part', 'appt', 'floor'];
//    $address = '';
//    foreach ($_POST as $field => $value) {
//        if ($value && in_array($field, $addressFields)) {
//            $address .= $value . ',';
//        }
//    }
//    $data = ['address' => $address];
//
//    $user = $burger->getUserByEmail($email);
//
//    if ($user) {
//        $user_Id = $user['id'];
//        $burger->incOrders($user['id']);
//        $orderNumber = $user['orders'] + 1;
//    } else {
//        $orderNumber = 1;
//        $user_Id = $burger->createUser($email, $name);
//    }
//    $orderId = $burger->addOrder($user_Id, $data);
//    echo "Спасибо, ваш заказ будет доставлен по адресу: “$address<br>”
//Номер вашего заказа: #$orderId <br>
//Это ваш $orderNumber заказ!";
//}
//main();
//
